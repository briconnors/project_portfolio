#pragma once
#include <stdint.h>

//network settings
constexpr unsigned long NETWORK_TIMEOUT = 15000; //ms
constexpr uint8_t FRAME_SEND_RETRY = 3;
constexpr uint8_t MISSING_FRAME = 3;

//device identification
constexpr char DEVICE_ID[] = "kitchen_camera";

//MQTT broker settings
constexpr char MQTT_BROKER[] = "192.168.4.1"; //Pi access point address
constexpr uint16_t MQTT_PORT = 8883; //encrypted MQTT port
constexpr char MQTT_CLIENT_ID[] = "nancy_kitchen_01";

//MQTT topics
constexpr char MQTT_STATUS_TOPIC[] = "nancy/kitchen/status";
constexpr char MQTT_COMMAND_TOPIC[] = "nancy/kitchen/command";
constexpr char MQTT_VISION_TOPIC[] = "nancy/kitchen/vision";
constexpr char MQTT_TELEMETRY_TOPIC[] = "nancy/kitchen/telemetry";
constexpr char MQTT_ALERT_TOPIC[] = "nancy/kitchen/alert";
