#pragma once
#include <string>

bool ConnectMqtt();
bool PublishMessage(const std::string& topic, const std::string& payload);
bool SubscribeTopic(const std::string& topic);
void ProcessMessages();
void DisconnectMqtt();
