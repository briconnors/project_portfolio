#include <Arduino.h>
#include <WiFi.h>
#include <NetworkClientSecure.h>
#include <HTTPClient.h>

#include "network.h"
#include "secrets.h"
#include "config.h"
#include "certs.h"

bool initNetwork(){
    WiFi.mode(WIFI_STA);
    WiFi.begin(
        Secrets::WIFI_SSID,
        Secrets::WIFI_PASSWORD
    );
    unsigned long startTime = millis(); 
    
    while (WiFi.status() != WL_CONNECTED){
        if (millis()-startTime > NETWORK_TIMEOUT){
            return false;
        }
        delay(100);
    }
    return true;
}

bool networkConnected(){
    return WiFi.status() == WL_CONNECTED;
}

void updateNetworkStatus(){
    if (!networkConnected()){
        recoverNetwork();
    }
}

bool recoverNetwork(){
    static unsigned long retryTime = 0;

    if (WiFi.status()==WL_CONNECTED){ //if it connects, great exit
        return true;
    }
    if (millis()-retryTime >= 5000){ //check if 5 secs passed
        WiFi.reconnect(); // retry connection
        retryTime = millis(); //update counter
    }
    return false;
}
