#include "mqtt_client.h" 
#include "types.h" 
#include "secrets.h"
#include "config.h"
#include "certificates.h"
#include <WiFi.h> //ESP32 WiFi library
#include <WiFiClientSecure.h> //encrypted TCP through TLS
#include <PubSubClient.h> //MQTT library for ESP32

extern Status status; //access shared status object defined in main.cpp

static WiFiClientSecure wifi; //creates TCP connection to Pi
static PubSubClient client(wifi); //creates MQTT client using TCP connection
static unsigned long lastAttempt = 0; //stores time of last reconnection attempt

//convert PubSubClient error codes into Nancy's error flags
static uint32_t GetMqttError(int code) {
    switch (code) {
        case -4: return MQTT_TIMEOUT;
        case -3: return MQTT_CONNECTION_LOST;
        case -2: return MQTT_CONNECT_FAILED;
        case -1: return MQTT_DISCONNECTED;
        case 1: return MQTT_BAD_PROTOCOL;
        case 2: return MQTT_BAD_CLIENT_ID;
        case 3: return MQTT_SERVER_UNAVAILABLE;
        case 4: return MQTT_BAD_CREDENTIALS;
        case 5: return MQTT_UNAUTHORIZED;
        default: return MQTT_NO_ERROR;
    }
}

//callback function automatically called when a subscribed MQTT message arrives
static void OnMessage(char* topic, byte* payload, unsigned int length) {
    //assemble received payload into a String
    String message;
    message.reserve(length);

    for (unsigned int i = 0; i < length; i++) {
        message += (char)payload[i];
    }

    //later: forward topic and message to Nancy's state machine
}

//main initialization call to establish MQTT connection with Pi broker
bool ConnectMqtt() {
    //prevent connecting multiple times
    if (client.connected()) {
        return true;
    }

    //verify WiFi connection before attempting MQTT
    if (WiFi.status() != WL_CONNECTED) {
        status.activeFaults |= NETWORK_FAILURE | MQTT_FAILURE;
        status.mqttErrors |= MQTT_DISCONNECTED;
        return false;
    }

    //configure MQTT broker, callback, and connection settings
    client.setServer(MQTT_BROKER, MQTT_PORT);
    client.setCallback(OnMessage);
    client.setKeepAlive(60);
    client.setSocketTimeout(2);
    client.setBufferSize(1024);
    //configure TLS certificate to verify Pi broker
    wifi.setCACert(MQTT_CA_CERT);

    //attempt broker connection with credentials and offline warning
    bool success = client.connect(
        MQTT_CLIENT_ID,
        MQTT_USER,
        MQTT_PASS,
        MQTT_STATUS_TOPIC,
        1,
        true,
        "offline"
    );

    //record MQTT failure and specific error if connection fails
    if (!success) {
        status.activeFaults |= MQTT_FAILURE;
        status.mqttErrors |= GetMqttError(client.state());
        return false;
    }

    //clear previous connection errors after successful connection
    status.mqttErrors = MQTT_NO_ERROR;

    //restore subscriptions so Pi can send commands and vision results
    bool commandOK = SubscribeTopic(MQTT_COMMAND_TOPIC);
    bool visionOK = SubscribeTopic(MQTT_VISION_TOPIC);

    //clear main MQTT failure if both subscriptions succeed
    if (commandOK && visionOK) {
        status.activeFaults &= ~MQTT_FAILURE;
    }

    //publish online status and record failure if publish unsuccessful
    if (!client.publish(MQTT_STATUS_TOPIC, "online", true)) {
        status.mqttErrors |= MQTT_PUBLISH_FAILED;
        status.activeFaults |= MQTT_FAILURE;
    }

    return commandOK && visionOK;
}

//subscribe Nancy to a topic so incoming messages can be received
bool SubscribeTopic(const String& topic) {
    //verify MQTT connection before attempting subscription
    if (!client.connected()) {
        status.activeFaults |= MQTT_FAILURE;
        status.mqttErrors |= MQTT_DISCONNECTED;
        return false;
    }

    //attempt subscription with QoS 1
    if (!client.subscribe(topic.c_str(), 1)) {
        status.activeFaults |= MQTT_FAILURE;
        status.mqttErrors |= MQTT_SUBSCRIBE_FAILED;
        return false;
    }

    return true;
}

//process incoming messages and attempt reconnection when necessary
void ProcessMessages() {
    //check WiFi connection and record failures if disconnected
    if (WiFi.status() != WL_CONNECTED) {
        status.activeFaults |= NETWORK_FAILURE | MQTT_FAILURE;
        status.mqttErrors |= MQTT_DISCONNECTED;
        return;
    }

    //clear network failure once WiFi reconnects
    status.activeFaults &= ~NETWORK_FAILURE;

    //process incoming messages if MQTT is connected
    if (client.connected()) {
        client.loop();

        //retry subscriptions if a previous subscription failed
        if (status.mqttErrors & MQTT_SUBSCRIBE_FAILED) {
            bool commandOK = SubscribeTopic(MQTT_COMMAND_TOPIC);
            bool visionOK = SubscribeTopic(MQTT_VISION_TOPIC);

            //clear subscription error if both subscriptions succeed
            if (commandOK && visionOK) {
                status.mqttErrors &= ~MQTT_SUBSCRIBE_FAILED;
            }
        }

        //clear main failure when connection and subscriptions are healthy
        if (client.connected() && status.mqttErrors == MQTT_NO_ERROR) {
            status.activeFaults &= ~MQTT_FAILURE;
        }
    }
    else {
        //record disconnected MQTT client and specific connection error
        status.activeFaults |= MQTT_FAILURE;
        status.mqttErrors |= GetMqttError(client.state());

        //attempt reconnection every 5 seconds without blocking main loop
        if (millis() - lastAttempt >= 5000) {
            lastAttempt = millis();
            ConnectMqtt();
        }
    }
}

//publish telemetry, alerts, or status messages to Pi
bool PublishMessage(const String& topic, const String& payload) {
    //verify MQTT connection before publishing
    if (!client.connected()) {
        status.activeFaults |= MQTT_FAILURE;
        status.mqttErrors |= MQTT_DISCONNECTED;
        return false;
    }

    //attempt to publish message to requested topic
    bool success = client.publish(
        topic.c_str(),
        payload.c_str()
    );

    //record publish failure or clear error if successful
    if (!success) {
        status.mqttErrors |= MQTT_PUBLISH_FAILED;
        status.activeFaults |= MQTT_FAILURE;
    }
    else {
        status.mqttErrors &= ~MQTT_PUBLISH_FAILED;
    }

    return success;
}

//cleanly disconnect MQTT client from Pi broker
void DisconnectMqtt() {
    if (client.connected()) {
        //announce intentional disconnection before closing connection
        client.publish(MQTT_STATUS_TOPIC, "offline", true);
        client.disconnect();
    }
}
