#pragma once

bool initCamera();
bool captureFrame();
bool recoverFrameSend();
bool recoverMissingFrame();
bool recoverCamera();