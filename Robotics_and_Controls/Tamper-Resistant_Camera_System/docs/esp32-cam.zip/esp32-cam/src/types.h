#pragma once
#include <stdint.h>
#include <esp_system.h>

enum State{
    INITIALIZE,
    ARMED,
    RECORDING,
    RECOVERY,
    TAMPER,
};

struct SensorData {
    bool pirMotion;
    uint16_t tofDistance; //distance in mm
    uint8_t tofStatus;
    
    bool mountPresent;
    bool externalPower;

    float accelerometerX;
    float accelerometerY;
    float accelerometerZ;
};

enum FailureSource : uint32_t {
    NO_FAULT = 0, 
    CAMERA_FAILURE = 1u << 0,
    TOF_FAILURE = 1u << 1,
    PIR_FAILURE = 1u << 2,
    ACCELEROMETER_FAILURE = 1u << 3,
    FRAME_MISSING = 1u << 4,
    FRAME_SEND_FAILURE = 1u << 5,
    NETWORK_FAILURE = 1u << 6,
    MQTT_FAILURE = 1u << 7
};

enum DetectionFlag {
    NO_DETECTION = 0,
    OBJECT_IN_PROXIMITY = 1u << 0,
    TOF_OBSTRUCTION = 1u << 1,
    ACCELERATION_DETECTED = 1u << 2,
    ORIENTATION_CHANGED = 1u << 3,
    MOUNT_DISCONNECTED = 1u << 4,
    EXTERNAL_POWER_LOST = 1u << 5,
    ENCLOSURE_OPENED = 1u << 6,
    MOISTURE_DETECTED_OUTSIDE = 1u << 7,
    MOISTURE_DETECTED_INSIDE = 1u << 8,
    LENS_OBSTRUCTION = 1u << 9
};

enum MqttError : uint32_t {
    MQTT_NO_ERROR = 0,
    MQTT_TIMEOUT = 1u << 0,
    MQTT_CONNECTION_LOST = 1u << 1,
    MQTT_CONNECT_FAILED = 1u << 2,
    MQTT_DISCONNECTED = 1u << 3,
    MQTT_BAD_PROTOCOL = 1u << 4,
    MQTT_BAD_CLIENT_ID = 1u << 5,
    MQTT_SERVER_UNAVAILABLE = 1u << 6,
    MQTT_BAD_CREDENTIALS = 1u << 7,
    MQTT_UNAUTHORIZED = 1u << 8,
    MQTT_SUBSCRIBE_FAILED = 1u << 9,
    MQTT_PUBLISH_FAILED = 1u << 10
};

struct Status{
    uint32_t activeFaults = NO_FAULT;
    uint32_t activeDetections = NO_DETECTION;
    uint32_t mqttErrors = MQTT_NO_ERROR;

    bool recording = false;
    uint32_t disabledFaults = NO_FAULT;
};

struct Recovery{
    uint8_t attempts[32] = {};
    unsigned long lastAttempt[32]={};
};

struct ESPResetData {
    esp_reset_reason_t reason = ESP_RST_UNKNOWN;

    bool powerFault = false;
    bool powerReset = false;
    bool softwareReset = false;
    bool watchdogFault = false;
    bool systemCrash = false;
};