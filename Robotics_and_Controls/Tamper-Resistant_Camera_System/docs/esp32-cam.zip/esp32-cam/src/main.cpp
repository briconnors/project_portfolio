#include <VL53L0X.h>
#include <Arduino.h>
#include <esp_system.h>

#include "types.h"
#include "sensors.h"
#include "camera.h"
#include "telemetry.h"
#include "network.h"

State state = INITIALIZE;
State previousState = ARMED;

Status status{};
SensorData sensors{};
DetectionFlag detection{};
Recovery recovery{};
ESPResetData espReset{};

void setup(){
    Serial.begin(115200);
    initNetwork();
    espReset.reason = esp_reset_reason();

    switch (espReset.reason) {//notifications built into esp
                case ESP_RST_BROWNOUT: //brownout
                    espReset.powerFault = true;
                    break;
                case ESP_RST_POWERON: //power on reset
                    espReset.powerReset = true;
                    break;
                case ESP_RST_SW: // software reset
                    espReset.softwareReset = true;
                    break;
                case ESP_RST_TASK_WDT: //task watchdog reset
                    espReset.watchdogFault = true;
                    break;
                case ESP_RST_PANIC: //system crash
                    espReset.systemCrash = true;
                    break;
            }
}

void loop(){
    if (state != INITIALIZE){ //continuous actions during state machine transitions
        updateSensorData();
        updateStateMachine();
        updatePowerStatus();
        updateNetworkStatus();
        publishHeartbeat();
        uploadFrame();
    }

    switch(state){
        case INITIALIZE: //startup the hardware and establish recent esp reset
            initToF();
            initPIR();
            initAccelerometer();
            initCamera();
            state = ARMED;
            break;

        case ARMED: //wait and check the sensor data for human presence or tampering
            checkToF(); 
            checkPIR();
            checkAccelerometer();
            checkMount();
            checkCamera();
            break;

        case RECORDING: //record during a motion or tampering event
            if (status.recording){
                    if (!captureFrame()){
                        previousState = state; //save prior state
                        state = RECOVERY; //move into recovery
                        break;
                    }
            }
            break;
        
        case RECOVERY: //report, retry, and fallback logic for hardware fails
            uint32_t activeFault = status.activeFaults & (~status.activeFaults + 1u); //isolate lowest bit first
            switch (activeFault) {
                case CAMERA_FAILURE:
                    if (recoverCamera()){
                        status.activeFaults &= ~CAMERA_FAILURE;
                    }
                    break;
                case TOF_FAILURE:
                    if (recoverToF()){
                        status.activeFaults &= ~TOF_FAILURE;
                    }
                    break;
                case PIR_FAILURE:
                    if (recoverPIR()){
                        status.activeFaults &= ~PIR_FAILURE;
                    }
                    break;
                case ACCELEROMETER_FAILURE:
                    if (recoverAccelerometer()){
                        status.activeFaults &= ~ACCELEROMETER_FAILURE;
                    }
                    break;
                case FRAME_MISSING:
                    if (recoverMissingFrame()){
                        status.activeFaults &= ~FRAME_MISSING;
                    }
                    break;
            default:
                break;
                }
            }
            if (status.activeFaults == NO_FAULT){
                state = previousState; //after fault resolves go back to prior task
            }
            break;
        
        case TAMPER://if the sensors detect unnatural conditions
        switch (activeDetections){
            case OBJECT_IN_PROXIMITY:
            case TOF_OBSTRUCTION:
            case ACCELERATION_DETECTED:
            case ORIENTATION_CHANGED:
            case MOUNT_DISCONNECTED:
            case EXTERNAL_POWER_LOST:
            case ENCLOSURE_OPENED:
            case MOISTURE_DETECTED_OUTSIDE:
            case MOISTURE_DETECTED_INSIDE:
            case LENSE_OBSTRUCTION:
            case NO_DETECTION:
        }
};
            break; 

        case DISARMED://if the remote control or fault protection manually shuts down
            break;
    }
}
