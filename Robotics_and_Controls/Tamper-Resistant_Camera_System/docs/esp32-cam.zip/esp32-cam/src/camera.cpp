#include "esp_camera.h"
#include "camera.h"

bool initCamera(){
    camera_config_t config = {};

    config.pin_pwdn = 32;
    config.pin_reset = -1;
    config.pin_xclk = 0;
    config.pin_sccb_sda = 26;
    config.pin_sccb_scl = 27;
    
    config.pin_d7 = 35;
    config.pin_d6 = 34;
    config.pin_d5 = 39;
    config.pin_d4 = 36;
    config.pin_d3 = 21;
    config.pin_d2 = 19;
    config.pin_d1 = 18;
    config.pin_d0 = 5;

    config.pin_vsync = 25;
    config.pin_href = 23;
    config.pin_pclk = 22;
    config.xclk_freq_hz = 2000000;
    config.ledc_timer = LEDC_TIMER_0;
    config.ledc_channel = LEDC_CHANNEL_0;

    config.pixel_format = PIXFORMAT_JPEG;
    config.frame_size = FRAMESIZE_VGA;
    config.jpeg_quality = 12;
    config.fb_count = 1;

    return esp_camera_init(&config) == ESP_OK;
}

bool captureFrame(){
    camera_fb_t* frame = esp_camera_fb_get();

    if(frame == nullptr){
        status.fault |= FRAME_MISSING;
        return false;
    }

    bool sent = recoverFrameSend(frame)
    esp_camera_fb_return(frame);
    if (!sent){
        status.fault |= FRAME_SEND_FAILED;
        return false;
    }
    return true;
}

bool recoverFrameSend(camera_fb_t* frame){
    bool sent = false;
    for (int i=0; i<3; i++){//for 3 attempts, send the frame out
        sent = sendFrame(frame->buf, frame->len);
        if (sent){ //if it gets sent, break early
            break;
        }
    }
    return sent;
}

bool recoverMissingFrame(){
    bool recovered = false;
    for (int i=0; i<3; i++){//for 3 attempts, retake the frame
        camera_fb_t* frame = esp_camera_fb_get(); //takes another frame
        if (frame == nullptr){
            continue; //if the frame fails retry
        }
        esp_camera_fb_return(frame);
        return true;
    }
    status.fault |= CAMERA_FAILURE
    return false;
}

bool recoverCamera(){
    esp_camera_deinit();
    return initCamera();
}
