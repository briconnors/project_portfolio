#pragma once

constexpr WIFI_SSID = "WIFI_NAME";
constexpr WIFI_PASSWORD = "WIFI_PASS";
constexpr DEVICE_ID = ""

constexpr char MQTT_USER[] = "nancy_kitchen";
constexpr char MQTT_PASS[] = "YOUR_MQTT_PASSWORD";