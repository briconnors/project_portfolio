#pragma once
#include <Arduino.h>

bool initNetwork();
bool networkConnected();
bool updateNetworkStatus();
bool recoverNetwork();

bool sendFrame(int8_t* data, size_t length); //read but dont modify the JPEG bytes


