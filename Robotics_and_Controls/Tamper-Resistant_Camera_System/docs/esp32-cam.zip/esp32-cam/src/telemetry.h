#pragma once
#include <esp_system.h>

#include "types.h"

char payload[256]; //array of bytes to store json

bool buildHeartbeatPayload(
    char* payload, //address of array
    size_t payloadSize, //size of array
    State state, //current operating state
    const Status& status, //reading structs
);

bool buildStartupPayload(
    char* payload, 
    size_t payloadSize,
    esp_reset_reason_t reason
);