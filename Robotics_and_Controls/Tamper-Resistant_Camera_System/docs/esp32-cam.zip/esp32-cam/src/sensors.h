#pragma once

void initTof();
void initPIR();
void initAccelerometer();
void initMount();

void checkToF();
void checkPIR();
void checkAccelerometer();
void checkMount();

void recoverToF();
void recoverPIR();
void recoverAccelerometer();

void updateSensorData();
void updateStateMachine();