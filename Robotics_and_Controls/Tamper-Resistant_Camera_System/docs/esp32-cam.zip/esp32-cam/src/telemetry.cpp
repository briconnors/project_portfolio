#include <Arduino.h>
#include <stdio.h>

#include "network.h"
#include "telemetry.h"

const char* stateToString(State state);

bool buildHeartbeatPayload(
    char* payload, //address of array
    size_t payloadSize, //size of array
    State state, //current operating state
    const Status& status, //reading structs
) {
    int length = snprintf(
        payload,
        payloadSize,
        "{"
            "\"state\":\"%s\","
            "\"faults\":%lu,"
            "\"wifi\":%s,"
            "\"detections\":%lu,"
            "\"uptime_ms\":%lu"
        "}",
        stateToString(state),
        static_cast<unsigned long>(status.activeFaults),
        networkConnected() ? "true": "false",
        static_cast<unsigned long>(status.activeDetections),
        static_cast<unsigned long>(millis())
    );


const char* stateToString(State state) {
    switch(state)
        case INITIALIZE: return "INITIALIZE";
        case ARMED: return "ARMED";
        case RECORDING: return "RECORDING";
        case RECOVERY: return "RECOVERY";
        case TAMPER: return "TAMPER";
        default: return "UNKNOWN"
    }
}
